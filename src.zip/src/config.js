// src/config.js
export const IRYS_NETWORK_URL = "https://node2.irys.xyz"; // Or whichever Irys node you prefer
