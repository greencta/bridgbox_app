import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom

const shortenAddress = (address) => {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
}

export default function TopBar({ wallet, handleDisconnect, profileCache, onProfile }) {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const dropdownRef = useRef(null);
    
    // Ensure wallet and wallet.address exist before trying to access properties
    const displayName = wallet && wallet.address
        ? profileCache[wallet.address.toLowerCase()] || shortenAddress(wallet.address)
        : 'Connect Wallet'; // Default display name if wallet not connected
    
    const displayAddress = wallet && wallet.address
        ? shortenAddress(wallet.address)
        : '';

    useEffect(() => {
        function handleClickOutside(event) {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsDropdownOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [dropdownRef]);

    return (
        <header className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex justify-between items-center">
            {/* IRYS Logo - now clickable and linked to home */}
            <Link to="/" className="flex items-center space-x-4 text-decoration-none">
                <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                <h1 className="text-2xl font-bold text-gray-800">IrysMail</h1>
            </Link>
            
            <div className="flex items-center space-x-6">
                {/* Search Icon */}
                <button className="text-gray-500 hover:text-gray-800"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 8a6 6 0 01-12 0h12z"></path></svg></button>
                {/* Notification Bell */}
                <button className="text-gray-500 hover:text-gray-800"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg></button>
                
                <div className="relative" ref={dropdownRef}>
                    {/* Wallet Display and Dropdown Trigger */}
                    {wallet && wallet.address ? (
                        <button onClick={() => setIsDropdownOpen(!isDropdownOpen)} className="flex items-center space-x-3 focus:outline-none cursor-pointer">
                            <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">
                                {displayName.charAt(0).toUpperCase()}
                            </div>
                            <div>
                                <p className="font-semibold text-gray-800 text-left">{displayName}</p>
                                <p className="text-xs text-gray-500 text-left">{displayAddress}</p>
                            </div>
                        </button>
                    ) : (
                        <span className="text-gray-500">Not Connected</span> // Display when wallet is not connected
                    )}

                    {/* Dropdown Menu */}
                    {isDropdownOpen && (
                        <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                             <button
                                onClick={() => {
                                    onProfile();
                                    setIsDropdownOpen(false);
                                }}
                                className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                            >
                                Your Profile
                            </button>
                            <button
                                onClick={() => {
                                    handleDisconnect();
                                    setIsDropdownOpen(false);
                                }}
                                className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50"
                            >
                                Disconnect
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
}