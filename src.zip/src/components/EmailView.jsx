import React from 'react';

const shortenAddress = (address) => {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
}

// A new component to render a single message within a thread
const MessageCard = ({ message, profileCache }) => {
    const fromDisplay = profileCache[message.from.toLowerCase()] || shortenAddress(message.from);
    const toDisplay = profileCache[message.to.toLowerCase()] || shortenAddress(message.to);
    const messageDate = new Date(message.timestamp).toLocaleString();

    return (
        <div className="border rounded-lg p-4 mb-4 bg-white">
            <div className="flex justify-between items-center mb-2">
                <p className="font-bold text-sm">{fromDisplay}</p>
                <p className="text-xs text-gray-500">{messageDate}</p>
            </div>
            <div className="whitespace-pre-wrap text-gray-800">
                {message.body}
            </div>
            {message.attachment && (
                <div className="mt-4 border-t pt-2">
                    <a
                        href={`https://gateway.irys.xyz/${message.attachment.txId}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center space-x-2 text-blue-600 hover:underline"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                        <span className="text-sm">{message.attachment.fileName}</span>
                    </a>
                </div>
            )}
        </div>
    );
};


export default function EmailView({ thread, profileCache, onReply }) {
  if (!thread) {
    return null; 
  }

  const lastMessage = thread.messages[thread.messages.length - 1];

  return (
    <div className="h-full p-6 flex flex-col">
      <div className="border-b pb-4 mb-6 flex justify-between items-center">
        <h1 className="text-3xl font-bold truncate">{thread.subject}</h1>
        <button 
            onClick={() => onReply(lastMessage)}
            className="flex items-center space-x-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold px-4 py-2 rounded-lg"
        >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M7.707 3.293a1 1 0 010 1.414L5.414 7H11a7 7 0 017 7v2a1 1 0 11-2 0v-2a5 5 0 00-5-5H5.414l2.293 2.293a1 1 0 11-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
            </svg>
            <span>Reply</span>
        </button>
      </div>
      
      <div className="flex-grow overflow-y-auto pr-2">
        {thread.messages.map(message => (
            <MessageCard key={message.id} message={message} profileCache={profileCache} />
        ))}
      </div>
    </div>
  );
}
