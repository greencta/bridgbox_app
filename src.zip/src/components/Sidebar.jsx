import React from 'react';

const SidebarLink = ({ icon, text, isActive, onClick }) => (
    <a 
        href="#" 
        onClick={onClick} 
        className={`flex items-center space-x-3 px-4 py-2 rounded-lg font-semibold ${isActive ? 'bg-blue-100 text-blue-600' : 'text-gray-600 hover:bg-gray-100'} ${onClick ? 'cursor-pointer' : ''}`}
    >
        {icon}
        <span>{text}</span>
    </a>
);

export default function Sidebar({ onCompose, onSelectView, currentView }) { 
    return (
        <div className="h-full bg-white rounded-lg shadow-sm border border-gray-200 p-4 flex flex-col">
            <button
                onClick={onCompose}
                className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 mb-6 shadow-md"
            >
                Compose
            </button>

            <nav className="space-y-2">
                <SidebarLink 
                    icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0l-8 5-8-5"></path></svg>}
                    text="Inbox"
                    isActive={currentView === 'inbox'} 
                    onClick={() => onSelectView('inbox')} 
                />
                <SidebarLink 
                    icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>}
                    text="Sent" 
                    isActive={currentView === 'sent'} 
                    onClick={() => onSelectView('sent')} 
                />
                <SidebarLink 
                    icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>}
                    text="Draft" 
                    isActive={currentView === 'draft'} 
                    onClick={() => onSelectView('draft')} 
                />
                <SidebarLink
                    icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H2v-2a3 3 0 015.356-1.857M7 20v-2m5-10a4 4 0 11-8 0 4 4 0 018 0zm0 0v1.5m3.673-10.41l-.895.894M13.673 17.034l.895.894M6.343 6.343l-.895-.895m12.728 0l-.895-.895M6.343 17.657l-.895.895M18.364 5.636l.895-.895M12 20h9a2 2 0 002-2V6a2 2 0 00-2-2H3a2 2 0 00-2 2v12a2 2 0 002 2h7"></path></svg>}
                    text="My Contacts"
                    isActive={currentView === 'contacts'}
                    onClick={() => onSelectView('contacts')}
                />
            </nav>

            <div className="mt-8">
                <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider px-4 mb-2">Labels</h3>
                <nav className="space-y-2">
                     <SidebarLink 
                        icon={<div className="w-5 h-5 flex items-center justify-center"><div className="w-2 h-2 rounded-full bg-blue-500"></div></div>}
                        text="Promotional" 
                    />
                     <SidebarLink 
                        icon={<div className="w-5 h-5 flex items-center justify-center"><div className="w-2 h-2 rounded-full bg-green-500"></div></div>}
                        text="Social" 
                    />
                </nav>
            </div>
        </div>
    );
}