import React, { useState, useEffect, useCallback } from 'react';
import { IRYS_NETWORK_URL } from '../config';

const shortenAddress = (address) => {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
};

export default function ContactsView({ wallet, irys }) {
    const [contacts, setContacts] = useState([]);
    const [newName, setNewName] = useState('');
    const [newAddress, setNewAddress] = useState('');
    const [status, setStatus] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [currentContactsTxId, setCurrentContactsTxId] = useState(null); 

    // Function to fetch contacts from Irys - MODIFIED TO RE-ADD RETRY LOGIC
    const fetchContacts = useCallback(async (retries = 0) => {
        const MAX_RETRIES = 10; // Max attempts to fetch contacts
        const BASE_DELAY = 1000; // Base delay in milliseconds (1 second)

        if (!wallet || !wallet.address) {
            setStatus('Connect wallet to load contacts.');
            setContacts([]);
            return;
        }

        // Only set isLoading to true on the first attempt
        if (retries === 0) {
            setIsLoading(true);
            setStatus('Loading contacts...'); // Initial status, no attempt count
        } else {
            setStatus('Checking for contacts list...'); // Subsequent attempts, still no attempt count
        }

        const query = `
            query {
                transactions(
                    owners: ["${wallet.address.toLowerCase()}"],
                    tags: [
                        { name: "App-Name", values: ["IrysMail"] },
                        { name: "Contacts-List", values: ["true"] }
                    ],
                    first: 1 
                ) {
                    edges {
                        node {
                            id
                        }
                    }
                }
            }
        `;

        console.log(`Fetching contacts list with query (Retry attempt ${retries + 1}):`, query);

        try {
            const graphqlURL = `${IRYS_NETWORK_URL}/graphql`;
            const response = await fetch(graphqlURL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query }),
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error("GraphQL response error text (fetchContacts):", errorText);
                throw new Error(`HTTP error! status: ${response.status}. Details: ${errorText}`);
            }

            const json = await response.json();
            console.log(`Raw GraphQL response for contacts list (Retry attempt ${retries + 1}):`, json);

            const edges = json.data.transactions.edges;

            if (edges.length > 0) {
                const contactsTxId = edges[0].node.id;
                setCurrentContactsTxId(contactsTxId); 
                setStatus(`Found contacts list. Fetching data...`);

                const dataResponse = await fetch(`https://gateway.irys.xyz/${contactsTxId}`);
                if (!dataResponse.ok) {
                    throw new Error(`Failed to fetch contacts data from gateway: ${dataResponse.status}`);
                }

                const contactsData = await dataResponse.json();
                console.log("Fetched contacts data:", contactsData);

                if (Array.isArray(contactsData)) {
                    setContacts(contactsData);
                    setStatus('Contacts loaded successfully!');
                } else {
                    setContacts([]);
                    setStatus('Contacts data found but is malformed. Starting with empty list.');
                    console.warn("Contacts data found but not an array:", contactsData);
                }
                setIsLoading(false); // Set loading to false once data is loaded or parsed
            } else {
                // If no contacts found, and max retries not reached, try again
                if (retries < MAX_RETRIES) {
                    const delay = BASE_DELAY * Math.pow(2, retries); // Exponential backoff
                    console.log(`Contacts not found, retrying in ${delay / 1000} seconds...`);
                    await new Promise(resolve => setTimeout(resolve, delay));
                    await fetchContacts(retries + 1); // Recursive call for retry
                } else {
                    // Max retries reached, still no contacts
                    setContacts([]);
                    setCurrentContactsTxId(null);
                    setStatus('No contacts found. Add your first contact!');
                    console.log("No contacts found after multiple retries.");
                    setIsLoading(false); // Set loading to false after all retries
                }
            }
        } catch (error) {
            console.error("Error fetching contacts:", error);
            setStatus(`Error fetching contacts: ${error.message}`);
            setContacts([]);
            setIsLoading(false); // Set loading to false on error
        }
    }, [wallet, IRYS_NETWORK_URL]); 

    useEffect(() => {
        if (wallet && wallet.address) {
            fetchContacts();
        } else {
            setContacts([]);
            setCurrentContactsTxId(null);
            setStatus('Connect your wallet to manage contacts.');
            setIsLoading(false);
        }
    }, [wallet, wallet.address, fetchContacts]);

    const handleAddContact = async () => {
        if (!newName.trim() || !newAddress.trim()) {
            setStatus('Please enter both name and wallet address.');
            return;
        }
        if (newAddress.trim().length < 30) {
            setStatus('Please enter a valid wallet address (too short).');
            return;
        }

        setIsLoading(true);
        setStatus('Adding contact...');

        const contactExists = contacts.some(contact => 
            contact.address.toLowerCase() === newAddress.trim().toLowerCase()
        );

        if (contactExists) {
            setStatus('This wallet address is already in your contacts.');
            setIsLoading(false);
            return;
        }
        
        const updatedContacts = [...contacts, { name: newName.trim(), address: newAddress.trim().toLowerCase() }];
        updatedContacts.sort((a, b) => a.name.localeCompare(b.name));

        const dataToUpload = JSON.stringify(updatedContacts);

        const tags = [
            { name: 'Content-Type', value: 'application/json' },
            { name: 'App-Name', value: 'IrysMail' },
            { name: 'Contacts-List', value: 'true' },
            { name: 'Owner-Address', value: wallet.address.toLowerCase() } 
        ];

        try {
            if (!irys) {
                throw new Error("Irys object not initialized. Cannot upload contacts.");
            }
            const receipt = await irys.upload(dataToUpload, { tags });
            setStatus(`Contact list updated successfully! (Tx ID: ${receipt.id})`);
            console.log(`Contacts data uploaded ==> https://gateway.irys.xyz/${receipt.id}`);
            setNewName('');
            setNewAddress('');
            
            // Re-fetch contacts immediately after upload (retry logic will handle indexing delay)
            fetchContacts(); 
            
        } catch (e) {
            setStatus(`Error saving contacts: ${e.message}`);
            console.error('Error saving contacts: ', e);
            setIsLoading(false); // Set loading to false on error
        }
    };

    const handleDeleteContact = async (addressToDelete) => {
        setIsLoading(true);
        setStatus('Deleting contact...');
    
        const updatedContacts = contacts.filter(contact => contact.address.toLowerCase() !== addressToDelete.toLowerCase());
        updatedContacts.sort((a, b) => a.name.localeCompare(b.name));
    
        const dataToUpload = JSON.stringify(updatedContacts);
    
        const tags = [
            { name: 'Content-Type', value: 'application/json' },
            { name: 'App-Name', value: 'IrysMail' },
            { name: 'Contacts-List', value: 'true' },
            { name: 'Owner-Address', value: wallet.address.toLowerCase() }
        ];
    
        try {
            if (!irys) {
                throw new Error("Irys object not initialized. Cannot update contacts.");
            }
            const receipt = await irys.upload(dataToUpload, { tags });
            setStatus(`Contact deleted successfully! (Tx ID: ${receipt.id})`);
            console.log(`Updated contacts data uploaded ==> https://gateway.irys.xyz/${receipt.id}`);
    
            // Re-fetch contacts immediately after deletion (retry logic will handle indexing delay)
            fetchContacts();
    
        } catch (e) {
            setStatus(`Error deleting contact: ${e.message}`);
            console.error('Error deleting contact: ', e);
            setIsLoading(false); // Set loading to false on error
        }
    };
    

    return (
        <div className="h-full p-6 flex flex-col">
            <h1 className="text-3xl font-bold border-b pb-4 mb-6">My Contacts</h1>
            
            <div className="mb-6 p-4 border rounded-lg bg-gray-50 shadow-sm">
                <h2 className="text-xl font-semibold mb-3">Add New Contact</h2>
                <div className="space-y-3">
                    <div>
                        <label htmlFor="contactName" className="block text-sm font-medium text-gray-700">Name</label>
                        <input
                            id="contactName"
                            type="text"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            className="mt-1 w-full p-2 border rounded-md"
                            placeholder="e.g., Alice Mail"
                            disabled={isLoading}
                        />
                    </div>
                    <div>
                        <label htmlFor="contactAddress" className="block text-sm font-medium text-gray-700">Wallet Address</label>
                        <input
                            id="contactAddress"
                            type="text"
                            value={newAddress}
                            onChange={(e) => setNewAddress(e.target.value)}
                            className="mt-1 w-full p-2 border rounded-md"
                            placeholder="e.g., 6kclflp3gbjmirwb7ui1ghct2febvt2kmyi6gxfuitrw"
                            disabled={isLoading}
                        />
                    </div>
                    <div className="flex justify-between items-center">
                        <p className="text-sm text-gray-600 h-5">{status}</p>
                        <button
                            onClick={handleAddContact}
                            disabled={isLoading || !wallet || !wallet.address || !irys}
                            className="bg-blue-600 text-white font-bold px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-300"
                        >
                            {isLoading ? 'Adding...' : 'Add Contact'}
                        </button>
                    </div>
                </div>
            </div>

            <h2 className="text-xl font-semibold mb-3">My Contacts ({contacts.length})</h2>
            <div className="flex-grow overflow-y-auto border rounded-lg bg-white shadow-sm">
                {isLoading && contacts.length === 0 ? (
                    <div className="p-4 text-center text-gray-500">Loading contacts...</div>
                ) : contacts.length === 0 ? (
                    <div className="p-4 text-center text-gray-500">No contacts added yet.</div>
                ) : (
                    <ul>
                        {contacts.map((contact, index) => (
                            <li key={contact.address} className="flex justify-between items-center p-4 border-b last:border-b-0 hover:bg-gray-50">
                                <div>
                                    <p className="font-semibold text-gray-800">{contact.name}</p>
                                    <p className="text-sm text-gray-500">{shortenAddress(contact.address)}</p>
                                </div>
                                <button
                                    onClick={() => handleDeleteContact(contact.address)}
                                    disabled={isLoading}
                                    className="text-red-500 hover:text-red-700 text-sm disabled:opacity-50"
                                >
                                    Delete
                                </button>
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
}