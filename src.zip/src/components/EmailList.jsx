import React from 'react';

const shortenAddress = (address) => {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
}

// NEW: Helper function to format the timestamp
const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();

    if (isToday) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
    } else {
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
};

export default function EmailList({ threads, onSelectThread, isLoading, onRefresh, searchQuery, setSearchQuery, profileCache, selectedThreadId }) {
  if (isLoading) {
    return <div className="p-4 text-center">Loading inbox...</div>;
  }

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b">
        <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
            </span>
            <input
                type="text"
                placeholder="Search"
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
            />
        </div>
      </div>
      
      <div className="flex-grow overflow-y-auto">
        {threads.length === 0 ? (
           <div className="p-4 text-center text-gray-500">{searchQuery ? 'No matching conversations found.' : 'Your inbox is empty.'}</div>
        ) : (
          <ul>
            {threads.map((thread) => {
              const lastMessage = thread.messages[thread.messages.length - 1];
              const senderDisplay = profileCache[lastMessage.from.toLowerCase()] || shortenAddress(lastMessage.from);
              const isActive = thread.id === selectedThreadId;
              
              return (
                <li 
                  key={thread.id} 
                  className={`border-b p-4 cursor-pointer ${isActive ? 'bg-blue-50' : 'hover:bg-gray-50'}`}
                  onClick={() => onSelectThread(thread)}
                >
                  <div className="flex justify-between items-start">
                    <p className={`font-bold text-sm truncate pr-2 ${isActive ? 'text-blue-700' : 'text-gray-800'}`}>{senderDisplay}</p>
                    {/* Display the formatted timestamp */}
                    <p className="text-xs text-gray-500 flex-shrink-0">{formatTimestamp(lastMessage.timestamp)}</p>
                  </div>
                  <p className={`font-semibold mt-1 ${isActive ? 'text-blue-800' : 'text-gray-900'}`}>{thread.subject}</p>
                  <p className="text-xs text-gray-500 truncate mt-1">{lastMessage.body}</p>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
