import React, { useState, useEffect, useCallback, useRef } from 'react';
import { PublicKey } from '@solana/web3.js';
import { Buffer } from 'buffer';

function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

const isValidSolanaAddress = (addr) => {
    try {
        new PublicKey(addr);
        return true;
    } catch (error) {
        return false;
    }
};

export default function ComposeView({ irys, onCancel }) {
  const [recipientInput, setRecipientInput] = useState('');
  const [resolvedAddress, setResolvedAddress] = useState(null);
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [status, setStatus] = useState('');
  const [isResolving, setIsResolving] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [attachment, setAttachment] = useState(null);
  const fileInputRef = useRef(null);

  const debouncedRecipientInput = useDebounce(recipientInput, 500);

  const resolveUsername = useCallback(async (name) => {
    if (!name) return;
    setIsResolving(true);
    setStatus('Resolving username...');
    setResolvedAddress(null);
    const query = `
      query {
        transactions(
          tags: [
            { name: "App-Name", values: ["IrysMail"] },
            { name: "Profile-Update", values: ["true"] },
            { name: "Username", values: ["${name.toLowerCase()}"] }
          ],
          first: 1
        ) {
          edges {
            node {
              address 
            }
          }
        }
      }
    `;
    try {
      const response = await fetch('https://node2.irys.xyz/graphql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      const json = await response.json();
      const edges = json.data.transactions.edges;
      if (edges.length > 0) {
        const address = edges[0].node.address;
        setResolvedAddress(address);
        setStatus(`Resolved to: ${address.substring(0, 8)}...`);
      } else {
        setStatus('Username not found.');
      }
    } catch (e) {
      console.error("Error resolving username", e);
      setStatus('Could not resolve username.');
    } finally {
      setIsResolving(false);
    }
  }, []);

  useEffect(() => {
    if (isValidSolanaAddress(debouncedRecipientInput)) {
      setResolvedAddress(debouncedRecipientInput);
      setStatus(`Valid address provided.`);
    } else if (debouncedRecipientInput) {
      resolveUsername(debouncedRecipientInput);
    } else {
      setResolvedAddress(null);
      setStatus('');
    }
  }, [debouncedRecipientInput, resolveUsername]);

  const handleFileChange = (e) => {
    if (e.target.files.length > 0) {
      setAttachment(e.target.files[0]);
    }
  };

  const handleCancelAttachment = () => {
    setAttachment(null);
    if(fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };

  const handleSend = async () => {
    if (!resolvedAddress) {
      setStatus('Please enter a valid recipient username or address.');
      return;
    }
    if (!subject || !body) {
      setStatus('Please fill in all fields.');
      return;
    }
    setIsSending(true);

    let attachmentReceipt = null;
    if (attachment) {
      try {
        setStatus('Reading file...');
        const fileBuffer = Buffer.from(await attachment.arrayBuffer());
        setStatus('Uploading attachment...');
        const attachmentTags = [{ name: 'Content-Type', value: attachment.type }];
        attachmentReceipt = await irys.upload(fileBuffer, { tags: attachmentTags });
        console.log(`Attachment uploaded ==> https://gateway.irys.xyz/${attachmentReceipt.id}`);
        setStatus('Attachment uploaded, preparing message...');
      } catch (e) {
        setStatus(`Error uploading attachment: ${e.message}`);
        console.error("Error during attachment upload:", e);
        setIsSending(false);
        return;
      }
    }

    const emailData = {
      to: resolvedAddress,
      subject: subject,
      body: body,
      attachment: attachmentReceipt ? {
        txId: attachmentReceipt.id,
        fileName: attachment.name,
        fileType: attachment.type,
      } : null,
    };
    const dataToUpload = JSON.stringify(emailData);

    const tags = [
      { name: 'Content-Type', value: 'application/json' },
      { name: 'App-Name', value: 'IrysMail' },
      { name: 'Recipient-Address', value: resolvedAddress.toLowerCase() },
    ];

    try {
      setStatus('Sending message...');
      const receipt = await irys.upload(dataToUpload, { tags });
      setStatus(`Message sent successfully!`);
      setTimeout(() => onCancel(), 2000);
    } catch (e) {
      setStatus(`Error sending message: ${e.message}`);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="h-full p-6 flex flex-col">
      <h1 className="text-3xl font-bold border-b pb-4 mb-6">New Message</h1>
      <div className="flex-grow flex flex-col">
        <div className="mb-4">
          <input
            type="text"
            placeholder="Recipient Username or Solana Address"
            value={recipientInput}
            onChange={(e) => setRecipientInput(e.target.value)}
            className={`w-full p-2 border rounded-md ${recipientInput && (resolvedAddress ? 'border-green-500' : 'border-red-500')}`}
          />
           <p className="text-xs text-gray-500 h-4 mt-1 pl-1">{isResolving ? 'Searching...' : (status || ' ')}</p>
        </div>
        <div className="mb-4">
          <input
            type="text"
            placeholder="Subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="w-full p-2 border rounded-md"
          />
        </div>
        <div className="mb-4 flex-grow">
          <textarea
            placeholder="Your message..."
            value={body}
            onChange={(e) => setBody(e.target.value)}
            className="w-full h-full p-2 border rounded-md resize-none"
          ></textarea>
        </div>
      </div>
      <div className="pt-4 border-t flex justify-between items-center">
        <div className="flex items-center">
          <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
          <button onClick={() => fileInputRef.current.click()} className="text-gray-500 hover:text-gray-800 p-2 rounded-full hover:bg-gray-200" title="Attach file">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
          </button>
          {attachment && (
            <div className="flex items-center space-x-2 bg-gray-100 rounded-full px-3 py-1">
              <span className="text-sm text-gray-700">{attachment.name}</span>
              <button onClick={handleCancelAttachment} className="text-gray-500 hover:text-red-600 font-bold">
                &times;
              </button>
            </div>
          )}
        </div>
        <div>
          <button onClick={onCancel} className="text-gray-600 font-bold px-6 py-2 rounded-lg hover:bg-gray-200 mr-2">
            Cancel
          </button>
          <button
            onClick={handleSend}
            disabled={isSending || !resolvedAddress}
            className="bg-blue-600 text-white font-bold px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-300 disabled:cursor-not-allowed"
          >
            {isSending ? 'Sending...' : 'Send'}
          </button>
        </div>
      </div>
    </div>
  );
}
