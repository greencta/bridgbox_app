import React, { useState, useEffect } from 'react';
import { IRYS_NETWORK_URL } from '../config';

export default function ProfileView({ wallet, irys }) {
  const [username, setUsername] = useState('');
  const [status, setStatus] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // This function now has more detailed logging
  const fetchProfile = async () => {
    setIsLoading(true);
    setStatus('Checking for existing profile...');
    
    const query = `
      query {
        transactions(
          owners: ["${wallet.address.toLowerCase()}"],
          tags: [
            { name: "App-Name", values: ["IrysMail"] },
            { name: "Profile-Update", values: ["true"] }
          ],
          first: 1
        ) {
          edges {
            node {
              id
            }
          }
        }
      }
    `;

    // DEBUG: Log the exact query we are sending
    console.log("Fetching profile with query:", query);

    try {
      const graphqlURL = `${IRYS_NETWORK_URL}/graphql`;
      const response = await fetch(graphqlURL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      const json = await response.json();

      // DEBUG: Log the raw response from the server
      console.log("Raw GraphQL response for profile:", json);
      
      const edges = json.data.transactions.edges;

      if (edges.length > 0) {
        const profileTxId = edges[0].node.id;
        const dataResponse = await fetch(`https://gateway.irys.xyz/${profileTxId}`);
        const profileData = await dataResponse.json();
        setUsername(profileData.username);
        setStatus('Existing profile loaded.');
      } else {
        setStatus('No profile found. Set your username below.');
      }
    } catch (e) {
      console.error("Error fetching profile", e);
      setStatus('Could not fetch profile.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (wallet.address) {
        fetchProfile();
    }
  }, [wallet.address]);


  const handleSaveProfile = async () => {
    if (!username) {
      setStatus('Please enter a username.');
      return;
    }
    setIsLoading(true);
    setStatus('Saving profile...');

    const profileData = { username: username };
    const dataToUpload = JSON.stringify(profileData);

    const tags = [
      { name: 'Content-Type', value: 'application/json' },
      { name: 'App-Name', value: 'IrysMail' },
      { name: 'Profile-Update', value: 'true' },
      { name: 'Username', value: username.toLowerCase() },
    ];

    try {
      const receipt = await irys.upload(dataToUpload, { tags });
      setStatus(`Profile saved successfully! (May take a minute to appear)`);
      console.log(`Profile data uploaded ==> https://gateway.irys.xyz/${receipt.id}`);
    } catch (e) {
      setStatus(`Error saving profile: ${e.message}`);
      console.error('Error saving profile ', e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-full p-6 flex flex-col">
      <h1 className="text-3xl font-bold border-b pb-4 mb-6">Your Profile</h1>
      <div className="space-y-4">
        <div>
          <label htmlFor="address" className="block text-sm font-medium text-gray-700">Wallet Address</label>
          <input id="address" type="text" readOnly value={wallet.address} className="mt-1 w-full p-2 border rounded-md bg-gray-100 cursor-not-allowed" />
        </div>
        <div>
          <label htmlFor="username" className="block text-sm font-medium text-gray-700">Username</label>
          <input id="username" type="text" placeholder="Choose a username" value={username} onChange={(e) => setUsername(e.target.value)} className="mt-1 w-full p-2 border rounded-md" />
        </div>
      </div>
      <div className="pt-6 mt-6 border-t flex justify-between items-center">
        <p className="text-sm text-gray-600 h-5">{status}</p>
        <button onClick={handleSaveProfile} disabled={isLoading} className="bg-blue-600 text-white font-bold px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-300">
          {isLoading ? 'Saving...' : 'Save Profile'}
        </button>
      </div>
    </div>
  );
}
