import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
// --- FIX: The import for BrowserRouter has been removed ---
// import { BrowserRouter } from 'react-router-dom'; 
import './index.css';
import App from './App.jsx';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    {/* --- FIX: The BrowserRouter wrapper has been removed --- */}
    <App />
  </StrictMode>,
);