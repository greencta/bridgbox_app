import React, { useMemo, useState, useEffect, lazy, Suspense } from 'react';
import { WebIrys } from "@irys/sdk";

// Solana Imports
import { ConnectionProvider, WalletProvider } from '@solana/wallet-adapter-react';
import { WalletModalProvider } from '@solana/wallet-adapter-react-ui';
import { PhantomWalletAdapter, SolflareWalletAdapter } from '@solana/wallet-adapter-wallets';
import { clusterApiUrl } from '@solana/web3.js';
import { useWallet } from '@solana/wallet-adapter-react';
import '@solana/wallet-adapter-react-ui/styles.css';

// App-specific Imports
import { IRYS_NETWORK_URL } from './config';
import ConnectPage from './pages/ConnectPage';
import './app.css';

const MailPage = lazy(() => import('./pages/MailPage'));

// --- DEBUGGING FUNCTION WITH LOGS AND A TIMEOUT ---
const getIrys = (solanaWallet) => new Promise((resolve, reject) => {
    // This will force an error if initialization takes more than 20 seconds
    const timeoutId = setTimeout(() => {
        reject(new Error("Irys initialization timed out after 20 seconds. The Irys network or Solana RPC may be down or blocked."));
    }, 20000); // 20 seconds

    const initialize = async () => {
        try {
            console.log("DEBUG: Entered getIrys function.");
            const url = IRYS_NETWORK_URL;
            const token = "solana";
            const rpcUrl = clusterApiUrl("devnet");
            console.log(`DEBUG: Config - Irys URL: ${url}, Solana RPC: ${rpcUrl}`);
            
            const wallet = { rpcUrl, name: "solana", provider: solanaWallet.adapter };

            console.log("DEBUG: Step 1: Calling 'new WebIrys(...)'.");
            const irysInstance = new WebIrys({ url, token, wallet });
            console.log("DEBUG: Step 2: 'new WebIrys' call completed.");

            console.log("DEBUG: Step 3: Calling 'await irysInstance.ready()'. This is the most likely place it will hang...");
            await irysInstance.ready();
            console.log("DEBUG: Step 4: 'irysInstance.ready()' completed successfully. Irys is ready!");

            clearTimeout(timeoutId);
            resolve(irysInstance);
        } catch (e) {
            clearTimeout(timeoutId);
            console.error("DEBUG: An error was thrown inside the getIrys function.", e);
            reject(e);
        }
    };

    initialize();
});

// The rest of the App.jsx remains the same...
function AppLogic() {
  const [irysInstance, setIrysInstance] = useState(null);
  const [initError, setInitError] = useState(null);
  const solanaWallet = useWallet();

  useEffect(() => {
    setInitError(null);

    if (solanaWallet.connected && solanaWallet.adapter && !irysInstance) {
      getIrys(solanaWallet)
        .then(setIrysInstance)
        .catch(error => {
          console.error("Irys (Solana) initialization failed:", error);
          setInitError(error);
        });
    } else if (!solanaWallet.connected && irysInstance) {
      setIrysInstance(null);
    }
  }, [solanaWallet.connected, solanaWallet.adapter, irysInstance]);

  const handleDisconnect = () => {
    if (solanaWallet.connected) {
      solanaWallet.disconnect();
    }
  };
  
  const isLoading = solanaWallet.connecting || (solanaWallet.connected && !irysInstance && !initError);
  const isReadyForMail = solanaWallet.connected && solanaWallet.publicKey && irysInstance;

  if (initError) {
    return (
        <div className="app-container error-container">
            <h1>Initialization Failed</h1>
            <p>Could not connect to the Irys network. Please check the console and refresh.</p>
            <pre style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-all', textAlign: 'left', background: '#333', padding: '1rem', borderRadius: '8px', marginTop: '1rem' }}>
                {initError.message}
            </pre>
        </div>
    );
  }

  if (isLoading) {
    return <div className="app-container">Initializing...</div>;
  }

  if (isReadyForMail) {
    return (
      <Suspense fallback={<div className="app-container">Loading Mail...</div>}>
        <MailPage
          wallet={{ address: solanaWallet.publicKey.toBase58(), irys: irysInstance }}
          handleDisconnect={handleDisconnect}
        />
      </Suspense>
    );
  }

  return <ConnectPage />;
}

const wallets = [
    new PhantomWalletAdapter(),
    new SolflareWalletAdapter(),
];

export default function App() {
    const network = "devnet"; 
    const endpoint = useMemo(() => clusterApiUrl(network), [network]);

    return (
        <ConnectionProvider endpoint={endpoint}>
            <WalletProvider wallets={wallets}>
                <WalletModalProvider>
                    <AppLogic />
                </WalletModalProvider>
            </WalletProvider>
        </ConnectionProvider>
    );
}