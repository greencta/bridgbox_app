import React from 'react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';

// THE FIX: Changed 'require' to 'import' to work with Vite
import '@solana/wallet-adapter-react-ui/styles.css'; 

export default function ConnectPage() {
  return (
    <div className="app-container">
      <p className="logo-text">IRYSMAIL</p>
      <h1 className="main-heading">Start your experience now</h1>
      {/* This button handles connecting, disconnecting, and changing wallets */}
      <WalletMultiButton />
    </div>
  );
}
