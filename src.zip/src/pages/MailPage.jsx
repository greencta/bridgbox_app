import React, { useState, useEffect, useMemo, useCallback } from 'react'; // Import useCallback
import { IRYS_NETWORK_URL } from '../config';
import Sidebar from '../components/Sidebar';
import EmailList from '../components/EmailList';
import EmailView from '../components/EmailView';
import ComposeView from '../components/ComposeView';
import ProfileView from '../components/ProfileView';
import ContactsView from '../components/ContactsView'; // Import ContactsView
import TopBar from '../components/TopBar';

const WelcomeView = () => (
    <div className="h-full flex items-center justify-center bg-white rounded-r-lg">
        <p className="text-gray-500">Select a conversation to read.</p>
    </div>
);

const getThreadId = (subject) => {
    return (subject || '').replace(/^(Re: )+/i, '').trim().toLowerCase();
};

export default function MailPage({ wallet, handleDisconnect }) {
    const [rightPaneView, setRightPaneView] = useState('welcome');
    const [selectedThread, setSelectedThread] = useState(null); 
    const [emails, setEmails] = useState([]);
    const [isLoadingEmails, setIsLoadingEmails] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [profileCache, setProfileCache] = useState({});
    const [composeInitialData, setComposeInitialData] = useState(null);
    const [currentView, setCurrentView] = useState('inbox'); 
    const [savedContacts, setSavedContacts] = useState([]); // New state for saved contacts

    // Function to fetch emails (inbox or sent)
    const fetchEmails = useCallback(async (viewType = 'inbox') => {
        setIsLoadingEmails(true);
        let queryTags = [{ name: "App-Name", values: ["IrysMail"] }];
        let queryOwners = [];

        if (viewType === 'inbox') {
            queryTags.push({ name: "Recipient-Address", values: [wallet.address.toLowerCase()] });
        } else if (viewType === 'sent') {
            queryOwners.push(wallet.address.toLowerCase());
        } else if (viewType === 'contacts') {
            setIsLoadingEmails(false); // Contacts are handled by ContactsView
            return;
        }

        const tagsString = queryTags.map(tag => {
            const valuesString = JSON.stringify(tag.values);
            return `{ name: "${tag.name}", values: ${valuesString} }`;
        }).join(', ');

        const emailQuery = `
            query {
                transactions(
                    ${queryOwners.length > 0 ? `owners: ${JSON.stringify(queryOwners)},` : ''}
                    tags: [${tagsString}],
                    first: 100
                ) {
                    edges { node { id, address, timestamp } }
                }
            }
        `;

        try {
            const graphqlURL = `${IRYS_NETWORK_URL}/graphql`;
            const emailRes = await fetch(graphqlURL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query: emailQuery }),
            });

            if (!emailRes.ok) { 
                const errorText = await emailRes.text();
                throw new Error(`GraphQL HTTP Error: ${emailRes.status} - ${errorText}`);
            }

            const emailJson = await emailRes.json();

            if (emailJson.errors) { 
                throw new Error(`GraphQL Query Error: ${JSON.stringify(emailJson.errors)}`);
            }
            const fetchedEdges = emailJson.data.transactions.edges;
            const emailsWithData = await Promise.all(
                fetchedEdges.map(async (edge) => {
                    const dataResponse = await fetch(`https://gateway.irys.xyz/${edge.node.id}`);
                    const emailData = await dataResponse.json();
                    return { id: edge.node.id, from: edge.node.address, timestamp: edge.node.timestamp, ...emailData };
                })
            );
            const sortedEmails = emailsWithData.sort((a, b) => b.timestamp - a.timestamp);
            
            const processedEmails = sortedEmails.map(email => ({
                ...email,
                from: viewType === 'sent' ? wallet.address.toLowerCase() : email.from.toLowerCase()
            }));
            setEmails(processedEmails);

            const addressesToCache = new Set();
            processedEmails.forEach(email => {
                addressesToCache.add(email.from.toLowerCase());
                if (email.to) addressesToCache.add(email.to.toLowerCase());
            });

            const addressesArray = [...addressesToCache];
            if (addressesArray.length > 0) {
                const profileQuery = `
                    query {
                        transactions(
                            owners: ${JSON.stringify(addressesArray)},
                            tags: [{ name: "App-Name", values: ["IrysMail"] }, { name: "Profile-Update", values: ["true"] }]
                        ) {
                            edges { node { id, address } }
                        }
                    }
                `;
                const profileRes = await fetch(graphqlURL, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ query: profileQuery }),
                });

                if (!profileRes.ok) {
                    const errorText = await profileRes.text();
                    throw new Error(`GraphQL HTTP Error (Profile): ${profileRes.status} - ${errorText}`);
                }

                const profileJson = await profileRes.json();
                if (profileJson.errors) {
                    throw new Error(`GraphQL Query Error (Profile): ${JSON.stringify(profileJson.errors)}`);
                }

                const profileEdges = profileJson.data.transactions.edges;
                const newCache = {};
                await Promise.all(
                    profileEdges.map(async (edge) => {
                        const dataRes = await fetch(`https://gateway.irys.xyz/${edge.node.id}`);
                        const profileData = await dataRes.json();
                        newCache[edge.node.address.toLowerCase()] = profileData.username;
                    })
                );
                setProfileCache(prevCache => ({ ...prevCache, ...newCache }));
            }
        } catch (error) {
            console.error("Error during fetchEmails:", error.message);
        } finally {
            setIsLoadingEmails(false);
        }
    }, [wallet.address, IRYS_NETWORK_URL]); // Add IRYS_NETWORK_URL to useCallback dependencies

    // Function to fetch saved contacts
    const fetchSavedContacts = useCallback(async () => {
        if (!wallet || !wallet.address) {
            setSavedContacts([]);
            return;
        }

        const query = `
            query {
                transactions(
                    owners: ["${wallet.address.toLowerCase()}"],
                    tags: [
                        { name: "App-Name", values: ["IrysMail"] },
                        { name: "Contacts-List", values: ["true"] }
                    ],
                    first: 1 
                ) {
                    edges {
                        node {
                            id
                        }
                    }
                }
            }
        `;

        try {
            const graphqlURL = `${IRYS_NETWORK_URL}/graphql`;
            const response = await fetch(graphqlURL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ query }),
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`GraphQL HTTP Error (Contacts): ${response.status} - ${errorText}`);
            }

            const json = await response.json();
            const edges = json.data.transactions.edges;

            if (edges.length > 0) {
                const contactsTxId = edges[0].node.id;
                const dataResponse = await fetch(`https://gateway.irys.xyz/${contactsTxId}`);
                if (!dataResponse.ok) {
                    throw new Error(`Failed to fetch contacts data from gateway: ${dataResponse.status}`);
                }
                const contactsData = await dataResponse.json();
                if (Array.isArray(contactsData)) {
                    setSavedContacts(contactsData);
                } else {
                    setSavedContacts([]);
                    console.warn("Fetched contacts data is not an array:", contactsData);
                }
            } else {
                setSavedContacts([]);
            }
        } catch (error) {
            console.error("Error fetching saved contacts:", error);
            setSavedContacts([]);
        }
    }, [wallet, IRYS_NETWORK_URL]);

    useEffect(() => {
        if (wallet.address) {
            fetchEmails(currentView);
            fetchSavedContacts(); // Fetch contacts when wallet address changes
        }
    }, [wallet.address, currentView, fetchEmails, fetchSavedContacts]); // Add fetchEmails and fetchSavedContacts to dependencies

    const threads = useMemo(() => {
        const grouped = emails.reduce((acc, email) => {
            const primaryParticipant = currentView === 'sent' ? email.to : email.from;
            const threadKey = `${primaryParticipant}-${getThreadId(email.subject)}`;

            if (!acc[threadKey]) {
                acc[threadKey] = {
                    id: threadKey,
                    subject: (email.subject || '').replace(/^(Re: )+/i, '').trim(),
                    messages: []
                };
            }
            const message = { 
                ...email, 
                from: email.from, 
                to: email.to 
            };
            acc[threadKey].messages.push(message);
            acc[threadKey].messages.sort((a, b) => a.timestamp - b.timestamp);
            return acc;
        }, {});

        return Object.values(grouped).sort((a, b) => {
            const lastMsgA = a.messages[a.messages.length - 1].timestamp;
            const lastMsgB = b.messages[b.messages.length - 1].timestamp;
            return lastMsgB - lastMsgA;
        });
    }, [emails, currentView, wallet.address]);


    const filteredThreads = threads.filter(thread => {
        const query = searchQuery.toLowerCase();
        return thread.subject.toLowerCase().includes(query) ||
               thread.messages.some(msg =>
                   msg.body.toLowerCase().includes(query) ||
                   msg.from.toLowerCase().includes(query) ||
                   (msg.to && msg.to.toLowerCase().includes(query))
               );
    });

    const handleSelectThread = (thread) => {
        setSelectedThread(thread);
        setRightPaneView('reading');
    };

    const handleReply = (email) => {
        const recipient = email.from === wallet.address.toLowerCase() ? email.to : email.from;
        const subject = email.subject.startsWith('Re: ') ? email.subject : `Re: ${email.subject}`;
        setComposeInitialData({ recipient, subject });
        setRightPaneView('composing');
    };

    const handleNewMessage = () => {
        setComposeInitialData(null);
        setRightPaneView('composing');
    };

    const handleCancelCompose = () => {
        setComposeInitialData(null);
        setRightPaneView('welcome');
    };

    const handleSendComplete = () => {
        setComposeInitialData(null);
        setRightPaneView('welcome');
        fetchEmails(currentView);
    };

    const renderRightPane = () => {
        switch (rightPaneView) {
            case 'composing':
                return <ComposeView
                    irys={wallet.irys}
                    onCancel={handleCancelCompose}
                    onSendComplete={handleSendComplete}
                    initialData={composeInitialData}
                    contacts={savedContacts} // Pass contacts to ComposeView
                />;
            case 'reading':
                return <EmailView
                    thread={selectedThread}
                    profileCache={profileCache}
                    onReply={handleReply}
                />;
            case 'profile':
                return <ProfileView wallet={wallet} irys={wallet.irys} />;
            case 'contacts':
                return <ContactsView wallet={wallet} irys={wallet.irys} />;
            default:
                return <WelcomeView />;
        }
    };

    return (
        <div className="w-screen h-screen bg-gray-100 p-4 flex flex-col">
            <TopBar
                wallet={wallet}
                handleDisconnect={handleDisconnect}
                profileCache={profileCache}
                onProfile={() => {
                    setRightPaneView('profile');
                    setCurrentView('profile');
                }}
            />
            <main className="flex-grow grid grid-cols-12 gap-4 mt-4">
                <div className="col-span-2">
                    <Sidebar
                        onCompose={handleNewMessage}
                        onSelectView={(view) => {
                            setCurrentView(view);
                            if (view === 'inbox' || view === 'sent') {
                                setRightPaneView('welcome');
                                setSelectedThread(null);
                            } else {
                                setRightPaneView(view);
                            }
                        }}
                        currentView={currentView}
                    />
                </div>
                <div className="col-span-3 bg-white rounded-lg shadow-sm border border-gray-200">
                    <EmailList
                        threads={filteredThreads}
                        onSelectThread={handleSelectThread}
                        isLoading={isLoadingEmails}
                        onRefresh={() => fetchEmails(currentView)}
                        searchQuery={searchQuery}
                        setSearchQuery={setSearchQuery}
                        profileCache={profileCache}
                        selectedThreadId={selectedThread?.id}
                    />
                </div>
                <div className="col-span-7 bg-white rounded-lg shadow-sm border border-gray-200">
                    {renderRightPane()}
                </div>
            </main>
        </div>
    );
}